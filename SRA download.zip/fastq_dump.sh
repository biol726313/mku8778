ml SRA-Toolkit/3.0.3-gompi-2022a

fastq-dump --split-files $1 -O /scratch/mbtoomey
